#-------------------------------------------------#
# Title: Working with Dictionaries
# Dev:   Christina Chung
# Date:  November, 12, 2018
# Description: Create a to-do file that will contain two columns of data
# (Task, Priority) which you store in a Python dictionary. Each Dictionary
# will represent one row of data and these rows of data are added to
# a Python List to create a table of data.
#-------------------------------------------------#

#-- Data --#
#Declare function, constants, and variables
def CurrentData():
    print()
    print("Current To-Do List:")
    for dicRow in lstTable:                                         #Loop through list table to output each row of dict
        print(dicRow["Task"] + " (" + dicRow["Priority"] + ")")

objTodoFile = open("C:\\_PythonClass\\Todo.txt", "r")               #Declare all variables
strTask = ""
dicRow = {}
lstTable = []
boolTaskFound = False

# Step 1 - Load data from a file
for line in objTodoFile:
    strTask = line.split(",")
    # Load each row of data in "ToDo.txt" into a python Dictionary.
    dicRow = {"Task":strTask[0], "Priority":strTask[1].strip("\n")}
    lstTable.append(dicRow)                                     # Add the each dictionary "row" to a python list "table"

while (True):
#--Input/Output---#
    # Step 2 - Display a menu of choices to the user
    print("""----------------------------------------------------------------------------------\n
    Menu of Options
    1) Show current data
    2) Add a new item
    3) Remove an existing item
    4) Save Data to File
    5) Exit Program
    """)
    strChoice = str(input("Which option would you like to perform? [1 to 4] - "))

#--Processing--#
    # Step 3 -Show the current items in the table
    if (strChoice.strip() == '1'):
        CurrentData()                                      #Calls functions defined above. Allows user to see curr data

    # Step 4 - Add a new item to the list/Table
    elif (strChoice.strip() == '2'):
        strTask = input("What is the task? - ")                             #Ask user for new task
        while (True):                                                       #Make sure the user enters a valid priority
            strPriority = input("What is the priority? (high/low) - ")
            if ((strPriority.lower() == "high") or (strPriority.lower() == "low")):     #Make sure priority is valid
                dicRow = {"Task":strTask, "Priority":strPriority}
                lstTable.append(dicRow)                                         #Add new task and priority to the table
                break
            else:
                print("Please re-enter \'high\' or \'low\' for the priority.")      #Error msg for invalid priority
                continue
        CurrentData()                                               #Print current data in table after newly added task
        continue

    # Step 5 - Remove a new item to the list/Table
    elif (strChoice == '3'):
        while(boolTaskFound == False):
            strTask = input("Which TASK would you like to remove? - ")      #Prompt user for task removing
            for dicRow in lstTable:
                if (dicRow["Task"].lower() == strTask.lower()):         #Search for task in list table
                    lstTable.remove(dicRow)                             #Remove task
                    boolTaskFound = True                                #Set sentinel for while loop
                    CurrentData()                                       #Print current data after removal
            if (boolTaskFound == False):
                print("Task not found in ToDo list. Please enter an existing task.")    #Error msg in case task DNE
                continue
        continue

    # Step 6 - Save tasks to the ToDo.txt file
    elif (strChoice == '4'):
        strSave = input("Save current data to file? (y/n) - ")      #Asks user if they want to save
        if (strSave == "y"):
            objTodoFile = open("C:\\_PythonClass\\Todo.txt", "w")  #Open file in write mode instead of read mode
            for dicRow in lstTable:                                 #Loop through table and add each dict row
                objTodoFile.write(dicRow["Task"] + "," + dicRow["Priority"] + "\n")
            objTodoFile.close()                                     #Save and close file
            break
        else:
            continue

    elif (strChoice == '5'):
        break  # and Exit the program
    else:                                                           #Make sure user enters in a valid menu option
        print("ERROR: Please choose a number from 1 to 5")
        continue