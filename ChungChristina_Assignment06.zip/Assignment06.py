#-------------------------------------------------#
# Title: Working with Dictionaries, Part 2
# Dev:   Christina Chung
# Date:  November, 12, 2018
# Description: Create a to-do file that will contain two columns of data
# (Task, Priority) which you store in a Python dictionary. Each Dictionary
# will represent one row of data and these rows of data are added to
# a Python List to create a table of data. SAME AS ASSIGNMENT 5, BUT
# WITH CLASSES AND FUNCTIONS
#-------------------------------------------------#


#Declare all variables
lstTable = []
strChoice = ""
boolTaskFound = False
strTask = ""
strPriority = ""
strSave = ""

#--Processing--#
class TodoList(object):
    """ This class contains methods for modifying/saving the To-Do List"""

    # Make a function for the code that loads the each
    # rows of data you have in the ToDo.txt text file into
    # a python Dictionary and adds it to a Python List.
    @staticmethod
    def LoadData(lstTable):
        objTodoFile = open("C:\\_PythonClass\\Todo.txt", "r")
        for line in objTodoFile:
            strTask = line.split(",")
            # Load each row of data in "ToDo.txt" into a python Dictionary.
            dicRow = {"Task": strTask[0], "Priority": strTask[1].strip("\n")}
            lstTable.append(dicRow)
        return lstTable

    # Make a function for the code that displays the contents
    # of the List to the user
    @staticmethod
    def DisplayData(lstTable):
        print()
        print("Current To-Do List:")
        for dicRow in lstTable:  # Loop through list table to output each row of dict
            print(dicRow["Task"] + " (" + dicRow["Priority"] + ")")
        print()

    # Make a function that displays a menu of options and call the
    # appropiate function dependent on the selected choice
    @staticmethod
    def MenuChoice(lstTable):
        print("""----------------------------------------------------------------------------------\n
            Menu of Options
            1) Show current data
            2) Add a new item
            3) Remove an existing item
            4) Save Data to File
            5) Exit Program
            """)
        print()
        TodoList.DisplayData(lstTable)

    # Make a function that allows users to add or remove content in the Python List
    @staticmethod
    def AddRemoveData(lstTable, strChoice, strTask, strPriority = None,):
        if (strChoice.strip() == '2'):
            dicRow = {"Task": strTask, "Priority": strPriority}
            lstTable.append(dicRow)  # Add new task and priority to the table
            return lstTable
        else:
            for dicRow in lstTable:
                if (dicRow["Task"].lower() == strTask.lower()):  # Search for task in list table
                    lstTable.remove(dicRow)  # Remove task
                    return lstTable

    # Make a function for the code that saves the data from the table into the
    # Todo.txt file when the program exits
    @staticmethod
    def SaveData(lstTable):
        objTodoFile = open("C:\\_PythonClass\\Todo.txt", "w")  # Open file in write mode instead of read mode
        for dicRow in lstTable:  # Loop through table and add each dict row
            objTodoFile.write(dicRow["Task"] + "," + dicRow["Priority"] + "\n")
        objTodoFile.close()  # Save and close file


# --Input/Output---#
lstTable = TodoList.LoadData(lstTable)      #Load initial data from Todo.txt file
while(True):
    TodoList.MenuChoice(lstTable)
    strChoice = str(input("Which option would you like to perform? [1 to 4] - "))

    if (strChoice.strip() == '1'):              #Choice 1: User wants to see data
        TodoList.DisplayData(lstTable)

    elif (strChoice.strip() == '2'):            #Choice 2: User wants to add ata
        strTask = input("What is the task? - ")
        while (True):  # Make sure the user enters a valid priority
            strPriority = input("What is the priority? (high/low) - ")
            if ((strPriority.lower() == "high") or (strPriority.lower() == "low")):  # Make sure priority is valid
                break
            else:
                print("Please re-enter \'high\' or \'low\' for the priority.")  # Error msg for invalid priority
                continue
        lstTable = TodoList.AddRemoveData(lstTable, strChoice, strTask, strPriority)
        TodoList.DisplayData(lstTable)
        continue

    elif (strChoice.strip() == '3'):            #Choice 3: User wants to remove data
        strTask = input("Which TASK would you like to remove? - ")
        lstTable = TodoList.AddRemoveData(lstTable, strChoice, strTask)
        TodoList.DisplayData(lstTable)
        continue

    elif (strChoice.strip() == '4'):            #Choice 4: User wants to save data
        strSave = input("Save current data to file? (y/n) - ")  # Asks user if they want to save
        if (strSave == "y"):
            TodoList.SaveData(lstTable)
            break
        else:
            continue

    elif (strChoice == '5'):                    #Choice 5: User wants to exit program
        break

    else:                                       #User enters invalid choice
        print("ERROR: Please choose a number from 1 to 5")
        continue




